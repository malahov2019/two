# Forward to success
There are no good languages, there are good programmers :thumbsup:

## Members:
*  Malakhov Roman
*  Golden Ilya